const LeftPanelLogo = () => {
  return (
    <div className="left-panel__logo">
      <div className="left-panel__logo-title">CRM заявки</div>
      <div className="left-panel__logo-subtitle">учебный проект webcademy</div>
    </div>
  );
};

export default LeftPanelLogo;
